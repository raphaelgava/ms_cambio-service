package com.example.cambio_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsCambioServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsCambioServiceApplication.class, args);
	}

}
